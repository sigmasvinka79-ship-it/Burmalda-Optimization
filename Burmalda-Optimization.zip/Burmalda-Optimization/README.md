# Burmalda Optimization (Fabric, Minecraft 1.21.11)

Нужны Fabric Loader >= 0.18.1 и Fabric API.

## Что внутри
- Меню мода: **Right Shift** (в игре, когда нет другого экрана)
- Мелкие предметы в руках (first/third person), GUI не трогается
- Тотем: текстура из фото, звук — скример (scream.ogg)
- Заряд ветра: текстура из фото
- Плащ (только у тебя, без смены): assets/burmalda_optimization/textures/cape.png
- Призраки вокруг цели, вспышка при ударе, эффект убийства
- Неоновый блеск зачарований, новые хотбар и прицел
- PvP-текстуры: мечи, золотые яблоки, жемчуг эндера, кристалл края
- Один раз правит options.txt под FPS (бэкап: options.txt.burmalda-backup)

## Настройка
Меню (Right Shift) или config/burmalda_optimization.properties.
Чтобы заново применить настройки FPS — удали config/burmalda_optimization.applied.v2

## Сборка
GitHub Actions: .github/workflows/build.yml. Jar — в build/libs/ (без -sources).
