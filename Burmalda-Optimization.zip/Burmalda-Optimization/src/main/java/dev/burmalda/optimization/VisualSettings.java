package dev.burmalda.optimization;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** Простой конфиг: config/burmalda_optimization.properties (меню: Right Shift) */
public final class VisualSettings {
    public static boolean ghosts = true;      // призраки вокруг цели
    public static boolean hitBurst = true;    // вспышка при ударе
    public static boolean killEffect = true;  // эффект при убийстве

    private VisualSettings() {}

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("burmalda_optimization.properties");
    }

    public static void load() {
        Path file = file();
        Properties p = new Properties();
        try {
            if (Files.exists(file)) {
                try (Reader r = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
                    p.load(r);
                }
            }
            ghosts = Boolean.parseBoolean(p.getProperty("ghosts", "true"));
            hitBurst = Boolean.parseBoolean(p.getProperty("hit_burst", "true"));
            killEffect = Boolean.parseBoolean(p.getProperty("kill_effect", "true"));
        } catch (IOException | RuntimeException ex) {
            System.out.println("[Burmalda Optimization] config error: " + ex);
        }
        save();
    }

    public static void save() {
        Path file = file();
        Properties p = new Properties();
        p.setProperty("ghosts", String.valueOf(ghosts));
        p.setProperty("hit_burst", String.valueOf(hitBurst));
        p.setProperty("kill_effect", String.valueOf(killEffect));
        try {
            Files.createDirectories(file.getParent());
            try (Writer w = Files.newBufferedWriter(file, StandardCharsets.UTF_8)) {
                p.store(w, "Burmalda Optimization: true/false");
            }
        } catch (IOException | RuntimeException ex) {
            System.out.println("[Burmalda Optimization] config save error: " + ex);
        }
    }
}
