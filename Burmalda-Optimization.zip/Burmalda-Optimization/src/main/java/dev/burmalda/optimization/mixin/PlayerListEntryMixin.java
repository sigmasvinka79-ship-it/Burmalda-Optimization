package dev.burmalda.optimization.mixin;

import com.mojang.authlib.GameProfile;
import dev.burmalda.optimization.BurmaldaCape;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.entity.player.SkinTextures;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Подменяет плащ только у локального игрока (тебя). */
@Mixin(PlayerListEntry.class)
public abstract class PlayerListEntryMixin {

    @Shadow
    public abstract GameProfile getProfile();

    @Unique
    private Boolean burmalda$local;

    @Inject(method = "getSkinTextures", at = @At("RETURN"), cancellable = true)
    private void burmalda$applyCape(CallbackInfoReturnable<SkinTextures> cir) {
        SkinTextures original = cir.getReturnValue();
        if (original != null && burmalda$isLocalPlayer()) {
            cir.setReturnValue(original.withOverride(BurmaldaCape.OVERRIDE));
        }
    }

    @Unique
    private boolean burmalda$isLocalPlayer() {
        Boolean cached = this.burmalda$local;
        if (cached != null) {
            return cached;
        }
        var player = MinecraftClient.getInstance().player;
        if (player == null) {
            return false;
        }
        boolean result = String.valueOf(this.getProfile()).contains(player.getUuid().toString());
        this.burmalda$local = result;
        return result;
    }
}
