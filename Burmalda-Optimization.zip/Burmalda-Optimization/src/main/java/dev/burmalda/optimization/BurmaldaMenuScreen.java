package dev.burmalda.optimization;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

/**
 * Меню мода (Right Shift). Лёгкое: без блюра и текстур, только прямоугольники
 * и кнопки. Анимация по времени (не по FPS): панель плавно проявляется,
 * кнопки по очереди выезжают, при закрытии — обратный ход.
 */
public class BurmaldaMenuScreen extends Screen {

    private static final float OPEN_MS = 320f;
    private static final float CLOSE_MS = 160f;
    private static final int BTN_W = 200;
    private static final int BTN_H = 20;
    private static final int GAP = 6;
    private static final int COUNT = 5; // заголовок + 3 переключателя + «Готово»

    private final long openedAt = System.nanoTime();
    private long closingAt = 0L;

    private final ButtonWidget[] buttons = new ButtonWidget[COUNT];
    private final int[] baseY = new int[COUNT];
    private int panelX1, panelY1, panelX2, panelY2;

    public BurmaldaMenuScreen() {
        super(Text.literal("Burmalda Optimization"));
    }

    private static Text label(String name, boolean on) {
        return Text.literal(name + ": " + (on ? "ВКЛ" : "ВЫКЛ"));
    }

    @Override
    protected void init() {
        int x = this.width / 2 - BTN_W / 2;
        int totalH = COUNT * BTN_H + (COUNT - 1) * GAP;
        int top = this.height / 2 - totalH / 2;

        ButtonWidget title = ButtonWidget.builder(Text.literal("Burmalda Optimization"), b -> { })
                .dimensions(x, top, BTN_W, BTN_H).build();
        title.active = false;

        ButtonWidget ghostsBtn = ButtonWidget.builder(label("Призраки", VisualSettings.ghosts), b -> {
            VisualSettings.ghosts = !VisualSettings.ghosts;
            b.setMessage(label("Призраки", VisualSettings.ghosts));
        }).dimensions(x, top + (BTN_H + GAP), BTN_W, BTN_H).build();

        ButtonWidget hitBtn = ButtonWidget.builder(label("Вспышка удара", VisualSettings.hitBurst), b -> {
            VisualSettings.hitBurst = !VisualSettings.hitBurst;
            b.setMessage(label("Вспышка удара", VisualSettings.hitBurst));
        }).dimensions(x, top + 2 * (BTN_H + GAP), BTN_W, BTN_H).build();

        ButtonWidget killBtn = ButtonWidget.builder(label("Эффект убийства", VisualSettings.killEffect), b -> {
            VisualSettings.killEffect = !VisualSettings.killEffect;
            b.setMessage(label("Эффект убийства", VisualSettings.killEffect));
        }).dimensions(x, top + 3 * (BTN_H + GAP), BTN_W, BTN_H).build();

        ButtonWidget doneBtn = ButtonWidget.builder(Text.literal("Готово"), b -> close())
                .dimensions(x, top + 4 * (BTN_H + GAP), BTN_W, BTN_H).build();

        buttons[0] = title;
        buttons[1] = ghostsBtn;
        buttons[2] = hitBtn;
        buttons[3] = killBtn;
        buttons[4] = doneBtn;
        for (int i = 0; i < COUNT; i++) {
            baseY[i] = top + i * (BTN_H + GAP);
            this.addDrawableChild(buttons[i]);
        }

        panelX1 = x - 12;
        panelX2 = x + BTN_W + 12;
        panelY1 = top - 12;
        panelY2 = top + totalH + 12;
    }

    @Override
    public void close() {
        if (closingAt == 0L) {
            closingAt = System.nanoTime();
        }
    }

    private void finish() {
        VisualSettings.save();
        if (this.client != null) {
            this.client.setScreen(null);
        }
    }

    private static float clamp01(float v) {
        return v < 0f ? 0f : (v > 1f ? 1f : v);
    }

    private static float easeOutCubic(float t) {
        float u = 1f - t;
        return 1f - u * u * u;
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        long now = System.nanoTime();
        float panel;
        float f;
        boolean closing = closingAt != 0L;
        if (closing) {
            float c = (now - closingAt) / 1_000_000f / CLOSE_MS;
            if (c >= 1f) {
                finish();
                return;
            }
            f = 1f - easeOutCubic(clamp01(c));
            panel = f;
            for (int i = 0; i < COUNT; i++) {
                buttons[i].setY(baseY[i] + (int) ((1f - f) * 14f));
            }
        } else {
            f = (now - openedAt) / 1_000_000f / OPEN_MS;
            panel = easeOutCubic(clamp01(f));
            for (int i = 0; i < COUNT; i++) {
                float p = easeOutCubic(clamp01((f - 0.08f * i) / 0.62f));
                buttons[i].setY(baseY[i] + (int) ((1f - p) * 18f));
            }
        }

        int off = (int) ((1f - panel) * 10f);
        int bg = ((int) (panel * 190f) << 24) | 0x0E0C18;
        int line = ((int) (panel * 255f) << 24) | 0x9A5CFF;
        context.fill(panelX1, panelY1 + off, panelX2, panelY2 + off, bg);
        context.fill(panelX1, panelY1 + off, panelX2, panelY1 + off + 2, line);

        super.render(context, mouseX, mouseY, delta);
    }
}
