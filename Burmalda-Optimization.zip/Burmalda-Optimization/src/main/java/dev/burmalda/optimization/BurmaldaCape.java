package dev.burmalda.optimization;

import net.minecraft.entity.player.SkinTextures;
import net.minecraft.util.AssetInfo;
import net.minecraft.util.Identifier;

import java.util.Optional;

/** Фиксированный плащ (assets/burmalda_optimization/textures/cape.png). */
public final class BurmaldaCape {

    public static final SkinTextures.SkinOverride OVERRIDE = new SkinTextures.SkinOverride(
            Optional.empty(),
            Optional.of(new AssetInfo.TextureAssetInfo(
                    Identifier.of("burmalda_optimization", "cape"),
                    Identifier.of("burmalda_optimization", "textures/cape.png"))),
            Optional.empty(),
            Optional.empty());

    private BurmaldaCape() {}
}
