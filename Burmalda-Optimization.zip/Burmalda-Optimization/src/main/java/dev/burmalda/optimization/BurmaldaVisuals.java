package dev.burmalda.optimization;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.ActionResult;
import org.lwjgl.glfw.GLFW;

import java.util.concurrent.ThreadLocalRandom;

/**
 * Визуалы (только клиент, обычные частицы — сквозь стены не видно):
 *  - "призраки": светящиеся шарики кружат вокруг игрока, которого ты ударил;
 *  - вспышка при ударе;
 *  - эффект души при убийстве.
 */
public class BurmaldaVisuals implements ClientModInitializer {

    private static final int GHOST_DURATION = 80; // 4 секунды после последнего удара

    private static Entity target;
    private static int ticksLeft;
    private static int age;
    private static boolean shiftWasDown;

    @Override
    public void onInitializeClient() {
        VisualSettings.load();

        AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            if (world.isClient() && entity instanceof LivingEntity && !entity.isInvisible()) {
                onHit(entity);
            }
            return ActionResult.PASS;
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> tick(client));
    }

    private static void onHit(Entity entity) {
        ClientWorld world = MinecraftClient.getInstance().world;
        if (world == null) {
            return;
        }
        target = entity;
        ticksLeft = GHOST_DURATION;
        if (VisualSettings.hitBurst) {
            hitBurst(world, entity);
        }
    }

    /** Right Shift открывает меню мода (только когда нет другого экрана). */
    private static void pollMenuKey(MinecraftClient client) {
        long window = GLFW.glfwGetCurrentContext();
        boolean down = window != 0L && GLFW.glfwGetKey(window, GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;
        if (down && !shiftWasDown && client.currentScreen == null) {
            client.setScreen(new BurmaldaMenuScreen());
        }
        shiftWasDown = down;
    }

    private static void tick(MinecraftClient client) {
        pollMenuKey(client);
        ClientWorld world = client.world;
        if (world == null || client.player == null) {
            target = null;
            return;
        }
        if (target == null || client.isPaused()) {
            return;
        }
        age++;

        if (!target.isAlive()) {
            boolean dead = target instanceof LivingEntity living && living.isDead();
            if (dead && VisualSettings.killEffect) {
                killBurst(world, target);
            }
            target = null;
            ticksLeft = 0;
            return;
        }

        ticksLeft--;
        if (ticksLeft <= 0 || client.player.squaredDistanceTo(target) > 1600.0) {
            target = null;
            return;
        }

        if (VisualSettings.ghosts) {
            spawnGhosts(world, target);
        }
    }

    private static void spawnGhosts(ClientWorld world, Entity e) {
        double radius = e.getWidth() * 0.75 + 0.3;
        double height = e.getHeight();
        for (int i = 0; i < 3; i++) {
            double angle = age * 0.22 + i * (Math.PI * 2.0 / 3.0);
            double x = e.getX() + Math.cos(angle) * radius;
            double z = e.getZ() + Math.sin(angle) * radius;
            double y = e.getY() + height * (0.5 + 0.38 * Math.sin(age * 0.13 + i * 2.1));
            world.addParticleClient(ParticleTypes.END_ROD, x, y, z, 0.0, 0.0, 0.0);
            if ((age + i) % 3 == 0) {
                world.addParticleClient(ParticleTypes.SOUL_FIRE_FLAME, x, y, z, 0.0, 0.01, 0.0);
            }
        }
    }

    private static void hitBurst(ClientWorld world, Entity e) {
        double cy = e.getY() + e.getHeight() * 0.55;
        double r = e.getWidth() * 0.6;
        int count = 14;
        for (int i = 0; i < count; i++) {
            double a = i * (Math.PI * 2.0 / count);
            world.addParticleClient(ParticleTypes.END_ROD,
                    e.getX() + Math.cos(a) * r, cy, e.getZ() + Math.sin(a) * r,
                    Math.cos(a) * 0.12, 0.02, Math.sin(a) * 0.12);
        }
    }

    private static void killBurst(ClientWorld world, Entity e) {
        ThreadLocalRandom rnd = ThreadLocalRandom.current();
        double cx = e.getX();
        double cy = e.getY() + e.getHeight() * 0.5;
        double cz = e.getZ();
        for (int i = 0; i < 28; i++) {
            double a = rnd.nextDouble() * Math.PI * 2.0;
            double up = rnd.nextDouble() * 2.0 - 1.0;
            double s = Math.sqrt(1.0 - up * up);
            world.addParticleClient(ParticleTypes.END_ROD, cx, cy, cz,
                    Math.cos(a) * s * 0.18, up * 0.18, Math.sin(a) * s * 0.18);
        }
        for (int i = 0; i < 10; i++) {
            world.addParticleClient(ParticleTypes.SOUL,
                    cx + (rnd.nextDouble() - 0.5) * e.getWidth(), cy,
                    cz + (rnd.nextDouble() - 0.5) * e.getWidth(),
                    0.0, 0.06 + rnd.nextDouble() * 0.04, 0.0);
        }
    }
}
