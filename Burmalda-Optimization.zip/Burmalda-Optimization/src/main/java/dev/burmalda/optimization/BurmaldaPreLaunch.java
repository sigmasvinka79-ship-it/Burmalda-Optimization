package dev.burmalda.optimization;

import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.entrypoint.PreLaunchEntrypoint;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Burmalda Optimization.
 *
 * Один раз (до запуска игры) правит options.txt под PvP/FPS.
 * Не трогает классы Minecraft, поэтому не зависит от маппингов.
 * Чтобы применить заново — удали config/burmalda_optimization.applied.v2
 */
public class BurmaldaPreLaunch implements PreLaunchEntrypoint {

    private static final String TAG = "[Burmalda Optimization] ";

    @Override
    public void onPreLaunch() {
        try {
            Path gameDir = FabricLoader.getInstance().getGameDir();
            Path options = gameDir.resolve("options.txt");
            Path marker = FabricLoader.getInstance().getConfigDir().resolve("burmalda_optimization.applied.v2");

            if (Files.exists(marker)) {
                return;
            }
            if (!Files.exists(options)) {
                // Первый запуск: options.txt ещё нет. Применим на следующем запуске.
                System.out.println(TAG + "options.txt не найден, настройки применятся при следующем запуске.");
                return;
            }

            Map<String, String> wanted = new LinkedHashMap<>();
            wanted.put("particles", "1");              // уменьшенные частицы
            wanted.put("entityShadows", "false");      // без теней сущностей
            wanted.put("biomeBlendRadius", "1");       // дешёвое смешивание биомов
            wanted.put("renderClouds", "\"false\"");   // без облаков
            wanted.put("enableVsync", "false");        // без VSync
            wanted.put("maxFps", "260");               // без лимита FPS
            wanted.put("menuBackgroundBlurriness", "0"); // без блюра в меню (быстрее)

            List<String> lines = new ArrayList<>(Files.readAllLines(options, StandardCharsets.UTF_8));
            Path backup = gameDir.resolve("options.txt.burmalda-backup");
            if (!Files.exists(backup)) {
                Files.copy(options, backup, StandardCopyOption.REPLACE_EXISTING);
            }

            for (Map.Entry<String, String> e : wanted.entrySet()) {
                String prefix = e.getKey() + ":";
                boolean replaced = false;
                for (int i = 0; i < lines.size(); i++) {
                    if (lines.get(i).startsWith(prefix)) {
                        lines.set(i, prefix + e.getValue());
                        replaced = true;
                        break;
                    }
                }
                if (!replaced) {
                    lines.add(prefix + e.getValue());
                }
            }

            Files.write(options, lines, StandardCharsets.UTF_8);
            Files.createDirectories(marker.getParent());
            Files.writeString(marker, "applied", StandardCharsets.UTF_8);
            System.out.println(TAG + "оптимальные настройки применены (бэкап: options.txt.burmalda-backup).");
        } catch (IOException | RuntimeException ex) {
            System.out.println(TAG + "не удалось применить настройки: " + ex);
        }
    }
}
